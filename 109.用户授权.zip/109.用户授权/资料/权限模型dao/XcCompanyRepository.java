package com.xuecheng.ucenter.dao;

import com.xuecheng.framework.domain.ucenter.XcCompany;
import org.springframework.data.jpa.repository.JpaRepository;


/**
 * Created by admin on 2018/2/7.
 */
public interface XcCompanyRepository extends JpaRepository<XcCompany, String> {
}
