package com.xuecheng.ucenter.dao;

import com.xuecheng.framework.domain.ucenter.XcRole;
import org.springframework.data.jpa.repository.JpaRepository;


/**
 * Created by admin on 2018/2/7.
 */
public interface XcRoleRepository extends JpaRepository<XcRole, String> {

}
