package cn.itcast.test;

public interface GetDataInter {

	public int getNumber();

}
