
package packb;
public class  DemoB
{
	/*public*/protected/*����*/  void method()
	{
		System.out.println("DemoB method run ");
	}
}
