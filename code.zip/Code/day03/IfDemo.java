class IfDemo 
{
	public static void main(String[] args) 
	{
//		System.out.println("Hello World!1");
//		System.out.println("Hello World!2");
//		System.out.println("Hello World!3");
//		System.out.println("Hello World!4");

		/*
		if���ĵ�һ�ָ�ʽ��
		1��
		if(��������ʽ)
		{
			ִ����䣻
		}
		*/

		int x = 1;
		if(x>1)
		{
		
			if(x<2)	
			{
			
				System.out.println("yes");	
				
			}
		}
		System.out.println("over");

	}
}
