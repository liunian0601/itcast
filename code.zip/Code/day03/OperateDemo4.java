class OperateDemo4 
{
	public static void main(String[] args) 
	{

//		System.out.println(6&3);
//		System.out.println(6|3);
//		System.out.println(~6);

		System.out.println(3<<2);//3������λ��

	}
}
