package cn.itcast.p4.generic.define.demo;

import cn.itcast.p2.bean.Student;
import cn.itcast.p2.bean.Worker;

public class GenericDefineDemo3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		Tool<Student> tool = new Tool<Student>();
		
//		tool.setObject(new Worker());
//		Student stu = tool.getObject();
//		Tool tool = new Tool();		
//		tool.setObject(new Worker());		
//		Student stu = (Student)tool.getObject();
		
		
	}

}


