class OperateDemo2 
{
	public static void main(String[] args) 
	{
		//��ֵ�������=  += -= *= /= %=
//		int a,b,c;
//		a = b = c = 4;

		//int a = 4;
		//a+=2;//a = a + 2;

		short s = 3;
		//s+=4;
		s = (short)(s + 4);


		System.out.println("s="+s);
	}
}
